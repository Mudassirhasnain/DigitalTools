'use client';

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Textarea } from '@/components/ui/Textarea';
import { Select } from '@/components/ui/Select';
import { Card } from '@/components/ui/Card';
import { CopyButton } from '@/components/ui/CopyButton';
import { FileDropzone } from '@/components/ui/FileDropzone';
import { Hash, CheckCircle2, XCircle, FileText, Key, Download, Sparkles } from 'lucide-react';

// Pure JS MD5 implementation for checksums
function md5(string: string): string {
  function rotateLeft(lValue: number, iShiftBits: number) {
    return (lValue << iShiftBits) | (lValue >>> (32 - iShiftBits));
  }
  function addUnsigned(lX: number, lY: number) {
    const lX8 = lX & 0x80000000;
    const lY8 = lY & 0x80000000;
    const lX4 = lX & 0x40000000;
    const lY4 = lY & 0x40000000;
    const lResult = (lX & 0x3fffffff) + (lY & 0x3fffffff);
    if (lX4 & lY4) return lResult ^ 0x80000000 ^ lX8 ^ lY8;
    if (lX4 | lY4) {
      if (lResult & 0x40000000) return lResult ^ 0xc0000000 ^ lX8 ^ lY8;
      return lResult ^ 0x40000000 ^ lX8 ^ lY8;
    }
    return lResult ^ lX8 ^ lY8;
  }
  function F(x: number, y: number, z: number) { return (x & y) | (~x & z); }
  function G(x: number, y: number, z: number) { return (x & z) | (y & ~z); }
  function H(x: number, y: number, z: number) { return x ^ y ^ z; }
  function I(x: number, y: number, z: number) { return y ^ (x | ~z); }
  function FF(a: number, b: number, c: number, d: number, x: number, s: number, ac: number) {
    a = addUnsigned(a, addUnsigned(addUnsigned(F(b, c, d), x), ac));
    return addUnsigned(rotateLeft(a, s), b);
  }
  function GG(a: number, b: number, c: number, d: number, x: number, s: number, ac: number) {
    a = addUnsigned(a, addUnsigned(addUnsigned(G(b, c, d), x), ac));
    return addUnsigned(rotateLeft(a, s), b);
  }
  function HH(a: number, b: number, c: number, d: number, x: number, s: number, ac: number) {
    a = addUnsigned(a, addUnsigned(addUnsigned(H(b, c, d), x), ac));
    return addUnsigned(rotateLeft(a, s), b);
  }
  function II(a: number, b: number, c: number, d: number, x: number, s: number, ac: number) {
    a = addUnsigned(a, addUnsigned(addUnsigned(I(b, c, d), x), ac));
    return addUnsigned(rotateLeft(a, s), b);
  }

  function convertToWordArray(str: string) {
    let lWordCount;
    const lMessageLength = str.length;
    const lNumberOfWords_temp1 = lMessageLength + 8;
    const lNumberOfWords_temp2 = (lNumberOfWords_temp1 - (lNumberOfWords_temp1 % 64)) / 64;
    const lNumberOfWords = (lNumberOfWords_temp2 + 1) * 16;
    const lWordArray = Array(lNumberOfWords - 1);
    let lBytePosition = 0;
    let lByteCount = 0;
    while (lByteCount < lMessageLength) {
      lWordCount = (lByteCount - (lByteCount % 4)) / 4;
      lBytePosition = (lByteCount % 4) * 8;
      lWordArray[lWordCount] = lWordArray[lWordCount] | (str.charCodeAt(lByteCount) << lBytePosition);
      lByteCount++;
    }
    lWordCount = (lByteCount - (lByteCount % 4)) / 4;
    lBytePosition = (lByteCount % 4) * 8;
    lWordArray[lWordCount] = lWordArray[lWordCount] | (0x80 << lBytePosition);
    lWordArray[lNumberOfWords - 2] = lMessageLength << 3;
    lWordArray[lNumberOfWords - 1] = lMessageLength >>> 29;
    return lWordArray;
  }

  function wordToHex(lValue: number) {
    let wordToHexValue = '', wordToHexValue_temp = '', lByte, lCount;
    for (lCount = 0; lCount <= 3; lCount++) {
      lByte = (lValue >>> (lCount * 8)) & 255;
      wordToHexValue_temp = '0' + lByte.toString(16);
      wordToHexValue = wordToHexValue + wordToHexValue_temp.substr(wordToHexValue_temp.length - 2, 2);
    }
    return wordToHexValue;
  }

  const x = convertToWordArray(string);
  let a = 0x67452301, b = 0xefcdab89, c = 0x98badcfe, d = 0x10325476;

  for (let k = 0; k < x.length; k += 16) {
    const AA = a, BB = b, CC = c, DD = d;
    a = FF(a, b, c, d, x[k + 0], 7, 0xd76aa478);
    d = FF(d, a, b, c, x[k + 1], 12, 0xe8c7b756);
    c = FF(c, d, a, b, x[k + 2], 17, 0x242070db);
    b = FF(b, c, d, a, x[k + 3], 22, 0xc1bdceee);
    a = FF(a, b, c, d, x[k + 4], 7, 0xf57c0faf);
    d = FF(d, a, b, c, x[k + 5], 12, 0x4787c62a);
    c = FF(c, d, a, b, x[k + 6], 17, 0xa8304613);
    b = FF(b, c, d, a, x[k + 7], 22, 0xfd469501);
    a = FF(a, b, c, d, x[k + 8], 7, 0x698098d8);
    d = FF(d, a, b, c, x[k + 9], 12, 0x8b44f7af);
    c = FF(c, d, a, b, x[k + 10], 17, 0xffff5bb1);
    b = FF(b, c, d, a, x[k + 11], 22, 0x895cd7be);
    a = FF(a, b, c, d, x[k + 12], 7, 0x6b901122);
    d = FF(d, a, b, c, x[k + 13], 12, 0xfd987193);
    c = FF(c, d, a, b, x[k + 14], 17, 0xa679438e);
    b = FF(b, c, d, a, x[k + 15], 22, 0x49b40821);

    a = GG(a, b, c, d, x[k + 1], 5, 0xf61e2562);
    d = GG(d, a, b, c, x[k + 6], 9, 0xc040b340);
    c = GG(c, d, a, b, x[k + 11], 14, 0x265e5a51);
    b = GG(b, c, d, a, x[k + 0], 20, 0xe9b6c7aa);
    a = GG(a, b, c, d, x[k + 5], 5, 0xd62f105d);
    d = GG(d, a, b, c, x[k + 10], 9, 0x02441453);
    c = GG(c, d, a, b, x[k + 15], 14, 0xd8a1e681);
    b = GG(b, c, d, a, x[k + 4], 20, 0xe7d3fbc8);
    a = GG(a, b, c, d, x[k + 9], 5, 0x21e1cde6);
    d = GG(d, a, b, c, x[k + 14], 9, 0xc33707d6);
    c = GG(c, d, a, b, x[k + 3], 14, 0xf4d50d87);
    b = GG(b, c, d, a, x[k + 8], 20, 0x455a14ed);
    a = GG(a, b, c, d, x[k + 13], 5, 0xa9e3e905);
    d = GG(d, a, b, c, x[k + 2], 9, 0xfcefa3f8);
    c = GG(c, d, a, b, x[k + 7], 14, 0x676f02d9);
    b = GG(b, c, d, a, x[k + 12], 20, 0x8d2a4c8a);

    a = HH(a, b, c, d, x[k + 5], 4, 0xfffa3942);
    d = HH(d, a, b, c, x[k + 8], 11, 0x8771f681);
    c = HH(c, d, a, b, x[k + 11], 16, 0x6d9d6122);
    b = HH(b, c, d, a, x[k + 14], 23, 0xfde5380c);
    a = HH(a, b, c, d, x[k + 1], 4, 0xa4beea44);
    d = HH(d, a, b, c, x[k + 4], 11, 0x4bdecfa9);
    c = HH(c, d, a, b, x[k + 7], 16, 0xf6bb4b60);
    b = HH(b, c, d, a, x[k + 10], 23, 0xbebfbc70);
    a = HH(a, b, c, d, x[k + 13], 4, 0x289b7ec6);
    d = HH(d, a, b, c, x[k + 0], 11, 0xeaa127fa);
    c = HH(c, d, a, b, x[k + 3], 16, 0xd4ef3085);
    b = HH(b, c, d, a, x[k + 6], 23, 0x04881d05);
    a = HH(a, b, c, d, x[k + 9], 4, 0xd9d4d039);
    d = HH(d, a, b, c, x[k + 12], 11, 0xe6db99e5);
    c = HH(c, d, a, b, x[k + 15], 16, 0x1fa27cf8);
    b = HH(b, c, d, a, x[k + 2], 23, 0xc4ac5665);

    a = II(a, b, c, d, x[k + 0], 6, 0xf4292244);
    d = II(d, a, b, c, x[k + 7], 10, 0x432aff97);
    c = II(c, d, a, b, x[k + 14], 15, 0xab9423a7);
    b = II(b, c, d, a, x[k + 5], 21, 0xfc93a039);
    a = II(a, b, c, d, x[k + 12], 6, 0x655b59c3);
    d = II(d, a, b, c, x[k + 3], 10, 0x8f0ccc92);
    c = II(c, d, a, b, x[k + 10], 15, 0xffeff47d);
    b = II(b, c, d, a, x[k + 1], 21, 0x85845dd1);
    a = II(a, b, c, d, x[k + 8], 6, 0x6fa87e4f);
    d = II(d, a, b, c, x[k + 15], 10, 0xfe2ce6e0);
    c = II(c, d, a, b, x[k + 6], 15, 0xa3014314);
    b = II(b, c, d, a, x[k + 13], 21, 0x4e0811a1);
    a = II(a, b, c, d, x[k + 4], 6, 0xf7537e82);
    d = II(d, a, b, c, x[k + 11], 10, 0xbd3af235);
    c = II(c, d, a, b, x[k + 2], 15, 0x2ad7d2bb);
    b = II(b, c, d, a, x[k + 9], 21, 0xeb86d391);

    a = addUnsigned(a, AA);
    b = addUnsigned(b, BB);
    c = addUnsigned(c, CC);
    d = addUnsigned(d, DD);
  }

  return (wordToHex(a) + wordToHex(b) + wordToHex(c) + wordToHex(d)).toLowerCase();
}

async function computeSubtleHash(algorithm: string, buffer: ArrayBuffer): Promise<Uint8Array> {
  const hashBuffer = await crypto.subtle.digest(algorithm, buffer);
  return new Uint8Array(hashBuffer);
}

async function computeHmac(algorithm: string, keyStr: string, buffer: ArrayBuffer): Promise<Uint8Array> {
  const enc = new TextEncoder();
  const keyData = enc.encode(keyStr);
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: { name: algorithm } },
    false,
    ['sign']
  );
  const signature = await crypto.subtle.sign('HMAC', cryptoKey, buffer);
  return new Uint8Array(signature);
}

function formatBytes(bytes: Uint8Array, format: 'hex_lower' | 'hex_upper' | 'base64'): string {
  if (format === 'base64') {
    let binary = '';
    for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  }
  const hex = Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  return format === 'hex_upper' ? hex.toUpperCase() : hex.toLowerCase();
}

export const CryptographicHashGenerator: React.FC = () => {
  const [sourceType, setSourceType] = useState<'text' | 'file'>('text');
  const [textInput, setTextInput] = useState('DigitalToools');
  const [fileDetails, setFileDetails] = useState<{ name: string; size: number } | null>(null);
  const [fileBuffer, setFileBuffer] = useState<ArrayBuffer | null>(null);

  // HMAC Mode
  const [enableHmac, setEnableHmac] = useState<boolean>(false);
  const [hmacSecretKey, setHmacSecretKey] = useState<string>('secret_api_key_2026');

  // Format option
  const [outputFormat, setOutputFormat] = useState<'hex_lower' | 'hex_upper' | 'base64'>('hex_lower');

  // Checksum comparison
  const [compareHash, setCompareHash] = useState('');

  const [hashes, setHashes] = useState<{
    sha256: string;
    sha512: string;
    sha384: string;
    sha1: string;
    md5: string;
  }>({
    sha256: '',
    sha512: '',
    sha384: '',
    sha1: '',
    md5: '',
  });

  const updateHashes = async () => {
    let buffer: ArrayBuffer;
    let strForMd5 = '';

    if (sourceType === 'text') {
      const encoder = new TextEncoder();
      buffer = encoder.encode(textInput).buffer as ArrayBuffer;
      strForMd5 = textInput;
    } else {
      if (!fileBuffer) return;
      buffer = fileBuffer;
      const bytes = new Uint8Array(fileBuffer);
      let binary = '';
      for (let i = 0; i < Math.min(bytes.length, 100000); i++) {
        binary += String.fromCharCode(bytes[i]);
      }
      strForMd5 = binary;
    }

    try {
      let bSha256: Uint8Array;
      let bSha512: Uint8Array;
      let bSha384: Uint8Array;
      let bSha1: Uint8Array;

      if (enableHmac && hmacSecretKey.trim()) {
        [bSha256, bSha512, bSha384, bSha1] = await Promise.all([
          computeHmac('SHA-256', hmacSecretKey, buffer),
          computeHmac('SHA-512', hmacSecretKey, buffer),
          computeHmac('SHA-384', hmacSecretKey, buffer),
          computeHmac('SHA-1', hmacSecretKey, buffer),
        ]);
      } else {
        [bSha256, bSha512, bSha384, bSha1] = await Promise.all([
          computeSubtleHash('SHA-256', buffer),
          computeSubtleHash('SHA-512', buffer),
          computeSubtleHash('SHA-384', buffer),
          computeSubtleHash('SHA-1', buffer),
        ]);
      }

      const computedMd5 = md5(strForMd5);
      const formattedMd5 =
        outputFormat === 'hex_upper'
          ? computedMd5.toUpperCase()
          : outputFormat === 'base64'
          ? btoa(computedMd5.match(/\w{2}/g)?.map((a) => String.fromCharCode(parseInt(a, 16))).join('') || '')
          : computedMd5.toLowerCase();

      setHashes({
        sha256: formatBytes(bSha256, outputFormat),
        sha512: formatBytes(bSha512, outputFormat),
        sha384: formatBytes(bSha384, outputFormat),
        sha1: formatBytes(bSha1, outputFormat),
        md5: formattedMd5,
      });
    } catch {
      // Ignore
    }
  };

  useEffect(() => {
    updateHashes();
  }, [sourceType, textInput, fileBuffer, enableHmac, hmacSecretKey, outputFormat]);

  const handleFileSelect = (file: File) => {
    setFileDetails({ name: file.name, size: file.size });
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as ArrayBuffer;
      setFileBuffer(result);
    };
    reader.readAsArrayBuffer(file);
  };

  const isMatching = (hashVal: string) => {
    const cleanCompare = compareHash.trim().toLowerCase();
    return cleanCompare && cleanCompare === hashVal.toLowerCase();
  };

  const downloadChecksumFile = () => {
    const filename = fileDetails ? fileDetails.name : 'input.txt';
    const content = `# Checksums generated by DigitalToools (https://digitaltoools.vercel.app)\n# File: ${filename}\n\nSHA256: ${hashes.sha256}\nSHA512: ${hashes.sha512}\nSHA384: ${hashes.sha384}\nSHA1:   ${hashes.sha1}\nMD5:    ${hashes.md5}\n`;
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}.sha256sum`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Source Type Toggle */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl">
          <button
            type="button"
            onClick={() => setSourceType('text')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              sourceType === 'text'
                ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Plain Text Digest</span>
          </button>
          <button
            type="button"
            onClick={() => setSourceType('file')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              sourceType === 'file'
                ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Hash className="w-3.5 h-3.5" />
            <span>File Checksum Integrity</span>
          </button>
        </div>

        {/* Output format selectors */}
        <div className="flex items-center gap-2 text-xs">
          <span className="font-semibold text-slate-500 uppercase tracking-wider">Format:</span>
          <select
            value={outputFormat}
            onChange={(e) => setOutputFormat(e.target.value as any)}
            className="px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white dark:border-slate-700 dark:bg-slate-900 font-mono text-xs"
          >
            <option value="hex_lower">Hex (Lowercase)</option>
            <option value="hex_upper">Hex (Uppercase)</option>
            <option value="base64">Base64</option>
          </select>
        </div>
      </div>

      {/* Input Workspace */}
      <Card className="space-y-4">
        {sourceType === 'text' ? (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Input String (UTF-8)
              </span>
              <div className="flex items-center gap-1 text-[11px] text-slate-400">
                <span>Presets:</span>
                <button
                  type="button"
                  onClick={() => setTextInput('')}
                  className="hover:underline text-blue-600 dark:text-blue-400"
                >
                  Empty String
                </button>
                <span>•</span>
                <button
                  type="button"
                  onClick={() => setTextInput('The quick brown fox jumps over the lazy dog')}
                  className="hover:underline text-blue-600 dark:text-blue-400"
                >
                  Fox Pangram
                </button>
              </div>
            </div>
            <Textarea
              rows={3}
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              placeholder="Type or paste payload string to digest..."
              aria-label="Hash input text"
            />
          </div>
        ) : (
          <div>
            {!fileBuffer ? (
              <FileDropzone
                onFileSelect={handleFileSelect}
                label="Drop a file here to calculate cryptographic checksums"
                helperText="Processes in browser memory with zero network uploads"
              />
            ) : (
              <div className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-xs">
                <div>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {fileDetails?.name}
                  </span>
                  <span className="text-slate-500 ml-2">
                    ({((fileDetails?.size || 0) / 1024).toFixed(1)} KB)
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <Button size="sm" variant="outline" onClick={downloadChecksumFile} leftIcon={<Download className="w-3.5 h-3.5" />}>
                    Export .sha256sum
                  </Button>
                  <button
                    type="button"
                    onClick={() => {
                      setFileBuffer(null);
                      setFileDetails(null);
                    }}
                    className="text-blue-600 hover:underline"
                  >
                    Change file
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* HMAC Mode Toggle */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={enableHmac}
                onChange={(e) => setEnableHmac(e.target.checked)}
                className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-amber-500" />
                <span>HMAC Mode (Keyed-Hash Message Authentication Code)</span>
              </span>
            </label>
          </div>

          {enableHmac && (
            <Input
              label="HMAC Secret Key"
              value={hmacSecretKey}
              onChange={(e) => setHmacSecretKey(e.target.value)}
              placeholder="Enter cryptographic secret key..."
              helperText="Generates signature verification tags for API authorization and webhook payload integrity."
            />
          )}
        </div>

        {/* Checksum Verification Box */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
          <Input
            label="Verify Against Expected Checksum"
            placeholder="Paste expected hash here (e.g. from software release page)..."
            value={compareHash}
            onChange={(e) => setCompareHash(e.target.value)}
          />
        </div>
      </Card>

      {/* Computed Hash Digests List */}
      <div className="space-y-3">
        {[
          {
            key: 'sha256',
            name: enableHmac ? 'HMAC-SHA-256 (API Signing Standard)' : 'SHA-256 (Modern Standard Recommended)',
            bits: '256 bits',
            val: hashes.sha256,
          },
          {
            key: 'sha512',
            name: enableHmac ? 'HMAC-SHA-512 (High Entropy)' : 'SHA-512 (High Entropy 512-bit Digest)',
            bits: '512 bits',
            val: hashes.sha512,
          },
          {
            key: 'sha384',
            name: enableHmac ? 'HMAC-SHA-384' : 'SHA-384 (Truncated SHA-2 Family)',
            bits: '384 bits',
            val: hashes.sha384,
          },
          {
            key: 'sha1',
            name: enableHmac ? 'HMAC-SHA-1' : 'SHA-1 (Legacy / Git Commit Hash)',
            bits: '160 bits',
            val: hashes.sha1,
          },
          {
            key: 'md5',
            name: 'MD5 (Legacy 128-bit Checksum)',
            bits: '128 bits',
            val: hashes.md5,
          },
        ].map((algo) => {
          const match = isMatching(algo.val);
          return (
            <Card
              key={algo.key}
              className={`p-4 transition-all ${
                match
                  ? 'border-emerald-500 bg-emerald-50/50 dark:border-emerald-800 dark:bg-emerald-950/30 ring-1 ring-emerald-500'
                  : ''
              }`}
            >
              <div className="flex items-center justify-between pb-1.5 flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
                    {algo.name}
                  </span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 font-mono">
                    {algo.bits}
                  </span>
                  {match && (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Exact Match Verified!</span>
                    </span>
                  )}
                </div>
                <CopyButton textToCopy={algo.val} size="sm" />
              </div>
              <div className="font-mono text-xs sm:text-sm text-slate-900 dark:text-slate-100 break-all select-all pt-1 leading-relaxed">
                {algo.val || 'Computing digest...'}
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
};
